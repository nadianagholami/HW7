#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
   char str[]="lets break this string into pieces";
   char* piece=strtok(str," ");
   printf("%s\n",piece);
   piece=strtok(NULL," ");
   printf("%s\n",piece);
return 0;
}