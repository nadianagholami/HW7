#include <stdio.h>
#include <string.h>

int main(){
    int n;
    printf("type the number of words in your languages");
    scanf("%d",&n);
    char array [n][100];
    char firstLan[n][100];
    char secondLan[n][100];
    //char sentense[1000];

    int m=0;
    for (int i=0; i<n;i++){
        printf("type word no.%d in both languages with a space\n",i);
        fgets(array, sizeof(array), stdin);    
        while(m!=100){
            if (array[i][m]==' '){
                for(int k=0;k<i;k++){
                    firstLan[i][k]=array[i][k];
                }
                for(int h=i;h<100;h++){
                    for (int p=0;p<100;p++){
                        secondLan[i][p]=array[i][h];}
                }
            }
            m++;
        }
    }
    /*printf("type a sentense made with first language words");
    fgets(sentense,1000,stdin);
    for(int j=0;j<1000;j++){
        if (strchr(space,sentense)){

        }
    }*/
    for (int y=0;y<n;y++){
        for(int x=0;x<100;x++){
            printf("%c",firstLan[y][x]);
    }}
    return 0;
}